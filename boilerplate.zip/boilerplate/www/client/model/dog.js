// Modelová třída pes
window.model.dog = class {

}
