<?php
return array (
  0 => 
  array (
    'App\\Presenters\\ErrorPresenter' => 
    array (
      'file' => '/Applications/MAMP/htdocs/boilerplate/app/presenters/ErrorPresenter.php',
      'time' => 1562475384,
    ),
    'App\\Presenters\\ApiPresenter' => 
    array (
      'file' => '/Applications/MAMP/htdocs/boilerplate/app/presenters/ApiPresenter.php',
      'time' => 1577471442,
    ),
    'App\\Presenters\\HomepagePresenter' => 
    array (
      'file' => '/Applications/MAMP/htdocs/boilerplate/app/presenters/HomepagePresenter.php',
      'time' => 1567016337,
    ),
    'App\\Presenters\\Error4xxPresenter' => 
    array (
      'file' => '/Applications/MAMP/htdocs/boilerplate/app/presenters/Error4xxPresenter.php',
      'time' => 1562475384,
    ),
  ),
  1 => 
  array (
  ),
);
