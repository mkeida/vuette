<?php
return array (
  0 => 
  array (
    'App\\Bootstrap' => 
    array (
      'file' => '/Applications/MAMP/htdocs/sandbox/app/Bootstrap.php',
      'time' => 1562475384,
    ),
    'App\\Presenters\\BooksPresenter' => 
    array (
      'file' => '/Applications/MAMP/htdocs/sandbox/app/presenters/BooksPresenter.php',
      'time' => 1576098344,
    ),
    'App\\Presenters\\ErrorPresenter' => 
    array (
      'file' => '/Applications/MAMP/htdocs/sandbox/app/presenters/ErrorPresenter.php',
      'time' => 1562475384,
    ),
    'App\\Presenters\\ApiPresenter' => 
    array (
      'file' => '/Applications/MAMP/htdocs/sandbox/app/presenters/ApiPresenter.php',
      'time' => 1576184745,
    ),
    'App\\Presenters\\HomepagePresenter' => 
    array (
      'file' => '/Applications/MAMP/htdocs/sandbox/app/presenters/HomepagePresenter.php',
      'time' => 1567016337,
    ),
    'App\\Presenters\\Error4xxPresenter' => 
    array (
      'file' => '/Applications/MAMP/htdocs/sandbox/app/presenters/Error4xxPresenter.php',
      'time' => 1562475384,
    ),
    'App\\Router\\RouterFactory' => 
    array (
      'file' => '/Applications/MAMP/htdocs/sandbox/app/router/RouterFactory.php',
      'time' => 1562475384,
    ),
  ),
  1 => 
  array (
  ),
);
